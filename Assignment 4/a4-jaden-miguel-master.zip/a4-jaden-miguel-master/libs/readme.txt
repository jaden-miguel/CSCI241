Put your heap.jar from A3 in this directory, or download the solution heap.jar and use that.
