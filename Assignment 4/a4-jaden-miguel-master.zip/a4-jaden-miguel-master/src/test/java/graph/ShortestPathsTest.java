// Jaden Miguel
// Spring 2020 CSCI241
// JUnit tests for ShortestPaths.java

package graph;

import static org.junit.Assert.*;
import org.junit.FixMethodOrder;

import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.net.URL;
import java.io.FileNotFoundException;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ShortestPathsTest {

    /* Performs the necessary gradle-related incantation to get the
       filename of a graph text file in the src/test/resources directory at
       test time.*/
    private String getGraphResource(String fileName) {
        ClassLoader classLoader = getClass().getClassLoader();
        URL resource = classLoader.getResource(fileName);
        return resource.getPath();
    }

    /** Placeholder test case. Write your own tests here.  Be sure to include
     * the @Test annotation above each test method, or JUnit will ignore it and
     * not run it as a test case. */
    @Test
    public void test00Nothing() {
      //simple first test case
      String s = getGraphResource("Simple0.txt");
      
      try {
        Graph simple0 = ShortestPaths.parseGraph("basic", s);
      } 
      catch (FileNotFoundException e) {
        fail("Could not find graph Simple0.txt");
        return;
      }
      assertTrue(true);
      assertEquals(2+2, 4);
    } 


    // test for accurate path length calculation
    @Test
    public void test01PathLength() {
      String fn = getGraphResource("Simple1.txt");
      Graph simple1;
      try {
        simple1 = ShortestPaths.parseGraph("basic", fn);
      } 
      catch (FileNotFoundException e) {
        fail("Could not find Simple1.txt");
        return;
      }

      ShortestPaths sp = new ShortestPaths();
      sp.compute(simple1.getNode("S"));

      assertEquals(9, sp.shortestPathLength(simple1.getNode("B")), 0);
      assertEquals(0, sp.shortestPathLength(simple1.getNode("S")), 0);
      assertEquals(8, sp.shortestPathLength(simple1.getNode("A")), 0);
      assertEquals(5, sp.shortestPathLength(simple1.getNode("C")), 0);
    }



    // test on simple2.txt with no shortest path
    @Test
    public void test02NoPath() {
      String s = getGraphResource("Simple2.txt");
      Graph simple2;
      try {
        simple2 = ShortestPaths.parseGraph("basic", s);
      } 
      catch (FileNotFoundException e) {
        fail("Could not find graph Simple2.txt");
        return;
      }

      ShortestPaths sp = new ShortestPaths();
      sp.compute(simple2.getNode("C"));

      assertEquals(null, sp.shortestPath(simple2.getNode("D")));
    }



    // test on simple2.txt, unreachable node!
    @Test
    public void test03UnreachableNode() {
      String s = getGraphResource("Simple2.txt");
      Graph simple2;
      try {
        simple2 = ShortestPaths.parseGraph("basic", s);
      } 
      catch (FileNotFoundException e) {
        fail("Could not find Simple2.txt");
        return;
      }
      ShortestPaths sp = new ShortestPaths();
      sp.compute(simple2.getNode("A"));

      assertEquals(Double.POSITIVE_INFINITY, sp.shortestPathLength(simple2.getNode("D")), 0);
    }





}
